<?php
$this->load->view('admin/layouts/header');
$this->load->view($content);
$this->load->view('admin/layouts/footer');
?>