<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Club Fenicia</title>
<link rel="shortcut icon" href="<?php echo base_url()?>/public/images/favicon.ico" type="image/x-icon">
<link rel="icon" href="<?php echo base_url()?>/public/images/favicon.ico" type="image/x-icon">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<link rel="stylesheet" href="<?php echo base_url()?>/public/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>/public/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>/public/css/ionicons.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>/public/css/AdminLTE.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>/public/css/skin-blue.min.css">
<link rel="stylesheet" href="<?php echo base_url()?>/public/css/dataTables.bootstrap.min.css">
<!--css-->
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/public/css/style.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>/public/css/responsive.css" media="all" />
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.css" rel="stylesheet" type="text/css" />
<!--css-->
<!--calendar-->
<link rel="stylesheet" href="<?php echo base_url()?>/public/css/bootstrap-datepicker.css">
<!--calendar-->
<script src="<?php echo base_url()?>/public/js/jquery.min.js"></script> 
<script type="text/javascript" src="<?php echo base_url()?>/public/js/bootbox.js"></script> 
</head>
