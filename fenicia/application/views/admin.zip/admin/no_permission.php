<div class="main-content">
  <div class="content-wrapper">
    <div class="container-fluid">     
      <!-- Basic form layout section start -->
      <section id="basic-form-layouts">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="clearfix"></div>
              <div class="card-header">
                <div class="page-title-wrap">
                  <h3>You do not have access to this page.</h3>                  
                </div>
              </div>              
            </div>
          </div>
        </div>
      </section>
      <!-- // Basic form layout section end -->
    </div>
  </div>
</div>